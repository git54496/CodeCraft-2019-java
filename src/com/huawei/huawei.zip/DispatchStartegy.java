package com.huawei;

public class DispatchStartegy {
    public static void dispatchCar(){
//            Car curCar = carList.get(i).getValue();
//
//            if(t)
//
////            //此时仍有可能有些车已经到了终点
////            if()
////
////            before(arriveCar);
//            if(!curCar.dispatch())
//            {
//                System.out.println("curT:"+t+"  car:"+curCar.getCarID()+"  cant reach.");
//                curCar.setInStartTime(curCar.getInStartTime()+laterTime);
//                Collections.sort(carList, new Comparator<Map.Entry<Integer, Car>>() {
//                    @Override
//                    public int compare(Map.Entry<Integer, Car> o1, Map.Entry<Integer, Car> o2) {
//                        return o1.getValue().compareTo(o2.getValue());
//                    }
//                });
//
//                i--;
//                continue;
//            }
//            updateGraph(curCar);
//
//            if (curCar.getInStartTime() > t) {
//                curCar.setOutStartTime(curCar.getInStartTime());
//                t = curCar.getInStartTime();
//            } else {
//                curCar.setOutStartTime(t);
//            }
//
//            carArriveTimeQueue.add(new ArrivalTime(curCar.getCarID(), curCar.getOutStartTime() + curCar.getDispatchTime()));

    }
}
