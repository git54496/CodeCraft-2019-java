package com.huawei;

public class DispatchStartegy {
    public static void dispatchCar(){

    }
}
